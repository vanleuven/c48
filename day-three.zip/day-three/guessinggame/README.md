#guessing game

James van Leuven
Project Assignment: Code: Start using GitHub! 

Description: uploading my local repo including guessing game assignment to github


Joke:

Two atoms are walking down the street.  One atom turns the corner and bam runs right into the other atom!  The first atom cries out, "Ouch! I think I lost an electron!"

"Are you sure?" asks the second atom.

To which the first atom replies, "Yes, I'm positive!"